﻿namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    enum NeuronType //тип нейрона
    {
        Hidden, //скрытый
        Output //выходной
    }

    enum NetworkMode //режим работы сети
    {
        Train, //обучение
        Test, //проверка
        Demo //распознование
    }
}
