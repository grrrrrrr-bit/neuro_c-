﻿using System;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    class HiddenLayer : Layer
    {
        public HiddenLayer(int neuronCount, int inputCount, string name, string weightsDirectory, Random random)
            : base(neuronCount, inputCount, NeuronType.Hidden, name, weightsDirectory, random) { }

        public double[] BackwardPass(double[] signals)
        {
            double[] deltas = new double[Neurons.Length];
            for (int i = 0; i < deltas.Length; i++)
                deltas[i] = Neurons[i].Derivative * signals[i];

            return PropagateAndUpdate(deltas);
        }
    }
}
