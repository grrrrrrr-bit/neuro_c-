﻿using System;
using System.Globalization;
using System.IO;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    abstract class Layer
    {
        private const double LearningRate = 0.05;
        private const double Momentum = 0.05;
        private readonly int inputCount;
        private readonly double learningRate;
        private readonly double[,] lastWeightChanges;
        private readonly string weightsPath;
        protected readonly Neuron[] Neurons;

        protected Layer(int neuronCount, int inputCount, NeuronType type, string name,
            string weightsDirectory, Random random)
        {
            this.inputCount = inputCount;
            Neurons = new Neuron[neuronCount];
            lastWeightChanges = new double[neuronCount, inputCount + 1];
            weightsPath = Path.Combine(weightsDirectory, name + "_memory.csv");

            // Масштабирование сохраняет начальные значения и шаг обучения в координатах b*w.
            double slope = type == NeuronType.Hidden ? Neuron.ActivationSlope : 1.0;
            double weightLimit = Math.Sqrt(6.0 / (inputCount + neuronCount)) / slope;
            learningRate = LearningRate / (slope * slope);
            string[] savedRows = File.Exists(weightsPath) ? File.ReadAllLines(weightsPath) : null;
            if (savedRows != null && savedRows.Length != neuronCount)
                throw new InvalidDataException("Неверное число нейронов в файле " + weightsPath);

            for (int i = 0; i < neuronCount; i++)
            {
                double[] weights;
                if (savedRows == null)
                {
                    weights = new double[inputCount + 1];
                    for (int j = 1; j < weights.Length; j++)
                        weights[j] = (2.0 * random.NextDouble() - 1.0) * weightLimit;
                }
                else
                {
                    weights = ParseWeights(savedRows[i]);
                }
                Neurons[i] = new Neuron(weights, type);
            }
        }

        public virtual double[] ForwardPass(double[] inputs)
        {
            if (inputs.Length != inputCount)
                throw new ArgumentException("Неверное число входных сигналов для слоя.", nameof(inputs));

            double[] outputs = new double[Neurons.Length];
            for (int i = 0; i < Neurons.Length; i++)
            {
                Neurons[i].Activator(inputs);
                outputs[i] = Neurons[i].Output;
            }
            return outputs;
        }

        protected double[] PropagateAndUpdate(double[] signals)
        {
            double[] previousSignals = new double[inputCount];
            for (int i = 0; i < Neurons.Length; i++)
            {
                Neuron neuron = Neurons[i];
                double step = learningRate * signals[i];
                UpdateWeight(i, 0, step);
                for (int j = 0; j < inputCount; j++)
                {
                    int weightIndex = j + 1;
                    previousSignals[j] += neuron.Weights[weightIndex] * signals[i];
                    UpdateWeight(i, weightIndex, step * neuron.Inputs[j]);
                }
            }
            return previousSignals;
        }

        public void SaveWeights()
        {
            string[] rows = new string[Neurons.Length];
            for (int i = 0; i < Neurons.Length; i++)
            {
                string[] values = Array.ConvertAll(Neurons[i].Weights,
                    weight => weight.ToString("G17", CultureInfo.InvariantCulture));
                rows[i] = string.Join(";", values);
            }

            Directory.CreateDirectory(Path.GetDirectoryName(weightsPath));
            string temporaryPath = weightsPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.WriteAllLines(temporaryPath, rows);
                if (File.Exists(weightsPath))
                    File.Replace(temporaryPath, weightsPath, null);
                else
                    File.Move(temporaryPath, weightsPath);
            }
            finally
            {
                File.Delete(temporaryPath);
            }
        }

        private double[] ParseWeights(string row)
        {
            string[] values = row.Split(';');
            if (values.Length != inputCount + 1)
                throw new InvalidDataException("Неверное число весов в файле " + weightsPath);

            return Array.ConvertAll(values,
                value => double.Parse(value, NumberStyles.Float, CultureInfo.InvariantCulture));
        }

        private void UpdateWeight(int neuronIndex, int weightIndex, double step)
        {
            double change = Momentum * lastWeightChanges[neuronIndex, weightIndex] + step;
            lastWeightChanges[neuronIndex, weightIndex] = change;
            Neurons[neuronIndex].Weights[weightIndex] += change;
        }
    }
}
