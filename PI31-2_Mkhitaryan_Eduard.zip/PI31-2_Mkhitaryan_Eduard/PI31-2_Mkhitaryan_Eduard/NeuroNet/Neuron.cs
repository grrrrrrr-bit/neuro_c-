﻿using System;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    class Neuron
    {
        private const double ActivationAmplitude = 1.0;
        internal const double ActivationSlope = 0.01;
        private readonly NeuronType type;

        public double[] Weights { get; }
        public double[] Inputs { get; private set; }
        public double Output { get; private set; }
        public double Derivative { get; private set; }

        public Neuron(double[] weights, NeuronType type)
        {
            Weights = weights;
            this.type = type;
        }

        public void Activator(double[] inputs)
        {
            Inputs = inputs;
            double sum = Weights[0];
            for (int i = 0; i < inputs.Length; i++)
                sum += inputs[i] * Weights[i + 1];

            if (type == NeuronType.Hidden)
            {
                Output = HyperbolicTangent(sum);
                Derivative = HyperbolicTangentDerivative(sum);
            }
            else
            {
                Output = sum; // Логит для общего softmax выходного слоя.
            }
        }

        internal static double HyperbolicTangent(double x)
        {
            // Эквивалент a * (exp(b*x) - exp(-b*x)) / (exp(b*x) + exp(-b*x)).
            double exponential = Math.Exp(-2.0 * ActivationSlope * Math.Abs(x));
            double magnitude = ActivationAmplitude * (1.0 - exponential) / (1.0 + exponential);
            return x < 0.0 ? -magnitude : magnitude;
        }

        internal static double HyperbolicTangentDerivative(double x)
        {
            // Производная по взвешенной сумме x.
            double exponential = Math.Exp(-2.0 * ActivationSlope * Math.Abs(x));
            double denominator = 1.0 + exponential;
            return 4.0 * ActivationAmplitude * ActivationSlope * exponential / (denominator * denominator);
        }
    }
}
