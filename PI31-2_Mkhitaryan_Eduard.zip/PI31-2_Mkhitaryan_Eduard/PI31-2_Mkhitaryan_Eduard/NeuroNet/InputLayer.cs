﻿using System;
using System.IO;
using System.Security.Policy;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    class InputLayer
    {
        //поля
        private double[,] trainset; //100 изобр обуч выборки
        private double[,] testset; //10 изоб тестов выборки

        //свойства
        public double[,] Trainset { get => trainset; }
        public double[,] Testset { get => testset; }

        //конструктор
        public InputLayer(NetworkMode nm)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory; //
            string[] tmpArrStr; //временный массив строк
            string[] tmpStr; //вспом массив элементов строк
            switch (nm)
            {
                case NetworkMode.Train:
                    tmpArrStr = File.ReadAllLines(path + "train.txt"); 
                    trainset = new double[tmpArrStr.Length, 16]; //определение массива обучающей вборки
                    for(int i=0;i< tmpArrStr.Length; i++) //цикр перебора выбокри
                    {
                        tmpStr = tmpArrStr[i].Split(' '); //iая строка разбивается на массив
                        for(int j = 0; j < 16; j++) //заполнение iой строки обучающей выборки
                        {
                            trainset[i,j]=double.Parse(tmpStr[j]); //строковое в число двойн точности
                        }
                    }
                    break;
                case NetworkMode.Test:
                    tmpArrStr = File.ReadAllLines(path + "test.txt");
                    testset = new double[tmpArrStr.Length, 16]; //определение массива тестовой вборки
                    for (int i = 0; i < tmpArrStr.Length; i++) //цикр перебора выбокри
                    {
                        tmpStr = tmpArrStr[i].Split(' '); //iая строка разбивается на массив
                        for (int j = 0; j < 16; j++) //заполнение iой строки обучающей выборки
                        {
                            testset[i, j] = double.Parse(tmpStr[j]); //строковое в число двойн точности
                        }
                    }
                    break;
            }
        }

        //перетасовка строк методом Фишера-Йетса
        public void Shuffling_Array_Rows(double[,] arr)
        {
            //int j; //номер случайно выбранной строки
            Random random = new Random();
            for (int i = arr.GetLength(0)-1; i >= 0; i--)
            {
                int r = random.Next(0, i+1);
                if (r == i) continue;
                for (int j = 0; j < arr.GetLength(1); j++)
                {
                    double tmp = arr[i, j];
                    arr[i, j] = arr[r, j];
                    arr[r, j] = tmp;
                }
            }
        }
    }
}