﻿using System;
using System.Linq;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    class OutputLayer : Layer
    {
        public OutputLayer(int neuronCount, int inputCount, string name, string weightsDirectory, Random random)
            : base(neuronCount, inputCount, NeuronType.Output, name, weightsDirectory, random) { }

        public override double[] ForwardPass(double[] inputs)
        {
            return Softmax(base.ForwardPass(inputs));
        }

        internal static double[] Softmax(double[] logits)
        {
            // Вычитание общего максимума сохраняет вероятности и предотвращает переполнение exp.
            double maximum = logits.Max();
            double[] probabilities = new double[logits.Length];
            for (int i = 0; i < logits.Length; i++)
                probabilities[i] = Math.Exp(logits[i] - maximum);

            double sum = probabilities.Sum();
            for (int i = 0; i < probabilities.Length; i++)
                probabilities[i] /= sum;

            return probabilities;
        }

        public double[] BackwardPass(double[] errors, double[] probabilities)
        {
            // Умножение сигнала квадратичной ошибки на якобиан softmax.
            double weightedError = 0.0;
            for (int i = 0; i < errors.Length; i++)
                weightedError += probabilities[i] * errors[i];

            double[] deltas = new double[errors.Length];
            for (int i = 0; i < deltas.Length; i++)
                deltas[i] = probabilities[i] * (errors[i] - weightedError);

            return PropagateAndUpdate(deltas);
        }
    }
}
