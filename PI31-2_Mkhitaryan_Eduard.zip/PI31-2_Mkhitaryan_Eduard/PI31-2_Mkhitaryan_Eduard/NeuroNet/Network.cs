﻿using System;
using System.IO;

namespace PI31_2_Mkhitaryan_Eduard.NeuroNet
{
    class Network
    {
        internal const int InputCount = 15;
        private const int FirstHiddenCount = 71;
        private const int SecondHiddenCount = 34;
        private const int OutputCount = 10;
        private const int EpochCount = 50;

        private readonly HiddenLayer hidden_layer1;
        private readonly HiddenLayer hidden_layer2;
        private readonly OutputLayer output_layer;

        public double[] Fact { get; private set; } = new double[OutputCount];
        public double[] E_error_avr { get; private set; }

        public Network()
        {
            string weightsDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "memory_15-71-34-10");
            Random random = new Random();
            hidden_layer1 = new HiddenLayer(FirstHiddenCount, InputCount, nameof(hidden_layer1), weightsDirectory, random);
            hidden_layer2 = new HiddenLayer(SecondHiddenCount, FirstHiddenCount, nameof(hidden_layer2), weightsDirectory, random);
            output_layer = new OutputLayer(OutputCount, SecondHiddenCount, nameof(output_layer), weightsDirectory, random);
        }

        public void ForwardPass(double[] netInput)
        {
            double[] firstHidden = hidden_layer1.ForwardPass(netInput);
            double[] secondHidden = hidden_layer2.ForwardPass(firstHidden);
            Fact = output_layer.ForwardPass(secondHidden);
        }

        public void Train()
        {
            InputLayer inputLayer = new InputLayer(NetworkMode.Train);
            double[,] samples = inputLayer.Trainset;
            int sampleCount = samples.GetLength(0);
            double[] pixels = new double[InputCount];
            double[] errors = new double[OutputCount];
            E_error_avr = new double[EpochCount];

            for (int epoch = 0; epoch < EpochCount; epoch++)
            {
                inputLayer.Shuffling_Array_Rows(samples);
                double squaredError = 0.0;
                for (int sample = 0; sample < sampleCount; sample++)
                {
                    for (int i = 0; i < pixels.Length; i++)
                        pixels[i] = samples[sample, i + 1];
                    ForwardPass(pixels);

                    int expected = (int)samples[sample, 0];
                    for (int i = 0; i < errors.Length; i++)
                    {
                        double target = i == expected ? 1.0 : 0.0;
                        errors[i] = target - Fact[i];
                        squaredError += errors[i] * errors[i];
                    }

                    double[] secondHiddenSignals = output_layer.BackwardPass(errors, Fact);
                    double[] firstHiddenSignals = hidden_layer2.BackwardPass(secondHiddenSignals);
                    hidden_layer1.BackwardPass(firstHiddenSignals);
                }
                E_error_avr[epoch] = squaredError / (2.0 * sampleCount * OutputCount);
            }

            hidden_layer1.SaveWeights();
            hidden_layer2.SaveWeights();
            output_layer.SaveWeights();
        }
    }
}
