﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using PI31_2_Mkhitaryan_Eduard.NeuroNet;

namespace PI31_2_Mkhitaryan_Eduard
{
    public partial class FormMain : Form
    {
        private double[] inputPixels; //массив входных данных
        private Network network;
        public FormMain()
        {
            InitializeComponent();
            inputPixels = new double[Network.InputCount]; //инициализация массива
            network = new Network();
        }

        //пиксельная кнопка: обработка клика
        private void Change_State_Pixel_Button_Click(object sender, EventArgs e)
        {
            //если изначально белая
            if (((Button)sender).BackColor == Color.White){
                ((Button)sender).BackColor = Color.Black; //смена цвета кнопки
                inputPixels[((Button)sender).TabIndex] = 1d; //смена значения в массиве
            }

            //если чзначально чёрная
            else{
                ((Button)sender).BackColor = Color.White; //смена цвета кнопки
                inputPixels[((Button)sender).TabIndex] = 0d; //смена значения в массиве
            }
        }

        private void button_SaveTrainSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "train.txt";
            string tmpStr = numericUpDown_NecesseryOutput.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++) {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += "\n";
            File.AppendAllText(path, tmpStr);
        }

        private void button_SaveTestSample_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "test.txt";
            string tmpStr = numericUpDown_NecesseryOutput.Value.ToString();

            for (int i = 0; i < inputPixels.Length; i++)
            {
                tmpStr += " " + inputPixels[i].ToString();
            }
            tmpStr += "\n";
            File.AppendAllText(path, tmpStr);
        }

        private void buttonRecognize_Click(object sender, EventArgs e)
        {
            network.ForwardPass(inputPixels);
            labelOutput.Text=network.Fact.ToList().IndexOf(network.Fact.Max()).ToString();
            labelPropobiloty.Text = (100 * network.Fact.Max()).ToString("0.00") + " %";
        }

        private void button_Train_Click(object sender, EventArgs e)
        {
            network.Train();
            chartEAvr.Series[0].Points.Clear();
            for(int i = 0; i < network.E_error_avr.Length; i++)
            {
                chartEAvr.Series[0].Points.AddY(network.E_error_avr[i]);
            }

            MessageBox.Show("Обучение успешно завершено", "Информация",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
